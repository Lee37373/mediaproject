"""Before/after mock-up: the generated UI sprites laid over a real game screenshot (not wired into the game)."""
import os
import sys
from PIL import Image, ImageDraw, ImageFont, ImageFilter

UI = os.path.join(os.path.dirname(__file__), "out", "ui")
OUT = os.path.join(os.path.dirname(__file__), "out")
BOLD = "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"
BLACK = "/usr/share/fonts/opentype/noto/NotoSansCJK-Black.ttc"
KR = 1  # Korean face inside the .ttc
INK = (42, 31, 51, 255)
SCALE = 0.5  # sprites are 2x art


def font(size, black=False):
    return ImageFont.truetype(BLACK if black else BOLD, size, index=KR)


def sprite(name):
    return Image.open(os.path.join(UI, name + ".png")).convert("RGBA")


def nine(name, w, h, border):
    """border = (L, T, R, B) in sprite pixels; output scaled by SCALE."""
    src = sprite(name)
    src = src.resize((max(1, round(src.width * SCALE)), max(1, round(src.height * SCALE))), Image.LANCZOS)
    L, T, R, B = [round(b * SCALE) for b in border]
    sw, sh = src.size
    out = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    xs = [(0, L, 0, L), (L, sw - R, L, w - R), (sw - R, sw, w - R, w)]
    ys = [(0, T, 0, T), (T, sh - B, T, h - B), (sh - B, sh, h - B, h)]
    for sx0, sx1, dx0, dx1 in xs:
        for sy0, sy1, dy0, dy1 in ys:
            if sx1 <= sx0 or sy1 <= sy0 or dx1 <= dx0 or dy1 <= dy0:
                continue
            out.alpha_composite(src.crop((sx0, sy0, sx1, sy1)).resize((dx1 - dx0, dy1 - dy0), Image.LANCZOS), (dx0, dy0))
    return out


def icon(name, size):
    return sprite("icon_" + name).resize((size, size), Image.LANCZOS)


def text(img, xy, s, size, fill=(255, 255, 255, 255), anchor="la", stroke=3, black=False, stroke_fill=INK):
    ImageDraw.Draw(img).text(xy, s, font=font(size, black), fill=fill, anchor=anchor, stroke_width=stroke, stroke_fill=stroke_fill)


def shadow(img, layer, xy, blur=8, offset=(0, 6), alpha=110):
    a = layer.split()[3].point(lambda v: v * alpha // 255)
    sh = Image.new("RGBA", layer.size, (0, 0, 0, 255))
    sh.putalpha(a)
    sh = sh.filter(ImageFilter.GaussianBlur(blur))
    img.alpha_composite(sh, (xy[0] + offset[0], xy[1] + offset[1]))
    img.alpha_composite(layer, xy)


def button(img, x, y, w, h, color, label, size=15):
    b = nine("button_" + color, w, h, (36, 30, 36, 40))
    img.alpha_composite(b, (x, y))
    text(img, (x + w // 2, y + h // 2 - 2), label, size, anchor="mm", stroke=2)


def bar(img, x, y, w, h, kind, ratio, label=None):
    img.alpha_composite(nine("bar_back", w, h, (18, 0, 18, 0)), (x, y))
    fw = max(int((w - 4) * ratio), h)
    img.alpha_composite(nine("bar_fill_" + kind, fw, h - 4, (15, 0, 15, 0)), (x + 2, y + 2))
    if label:
        text(img, (x + w // 2, y + h // 2 - 1), label, 11, anchor="mm", stroke=2)


def build(shot_path):
    shot = Image.open(shot_path).convert("RGBA")
    game = shot.crop((0, 128, 1389, 800))  # the Game view area
    game.save(os.path.join(OUT, "mockup_before.png"))
    img = game.copy()
    W, H = img.size

    # --- top bar (replaces the flat HUD strip)
    hud = nine("panel_well", W - 16, 46, (28, 28, 28, 28))
    img.alpha_composite(Image.new("RGBA", (W, 40), (20, 14, 30, 255)), (0, 0))
    img.alpha_composite(hud, (8, 2))
    text(img, (26, 25), "2일차  10:00", 17, fill=(255, 226, 120, 255), anchor="lm", black=True)
    x = 560
    for ic, val in [("gold", "1,034"), ("food", "8"), ("exp", "250"), ("material", "12"), ("guild", "4/6")]:
        img.alpha_composite(icon(ic, 34), (x, 8))
        text(img, (x + 38, 25), val, 16, anchor="lm", stroke=3)
        x += 120

    # --- left menu (replaces the flat buttons)
    labels = ["의뢰 게시판 Q", "길드원 R", "창고 I", "살림 K", "생태계 E", "행상인 T", "건설 B", "정산 L",
              "추모의 벽 H", "관계도 G", "알림 N"]
    colors = ["yellow"] + ["purple"] * 10
    side = nine("panel_window_purple", 140, 48 + len(labels) * 31, (56, 56, 56, 56))
    img.alpha_composite(side, (0, 40))
    for i, (lb, col) in enumerate(zip(labels, colors)):
        button(img, 12, 54 + i * 31, 116, 30, col, lb, 12)

    todo = nine("panel_card", 214, 128, (36, 36, 36, 36))
    img.alpha_composite(todo, (0, 434))
    text(img, (14, 446), "지금 챙길 것", 14, fill=(255, 214, 110, 255), black=True)
    text(img, (14, 472), "게시판이 비어 쉬는 길드원이", 12, stroke=0)
    text(img, (14, 490), "4명 있습니다. 의뢰를 올리세요.", 12, stroke=0)
    button(img, 14, 516, 120, 32, "green", "의뢰 올리기", 12)

    # --- window: 길드원
    ww, wh = 600, 470
    wx, wy = (W - ww) // 2 + 40, 92
    win = nine("panel_window_purple", ww, wh, (56, 56, 56, 56))
    shadow(img, win, (wx, wy), 10, (0, 8), 120)
    rib = nine("title_ribbon_red", 300, 60, (120, 0, 120, 0))
    img.alpha_composite(rib, (wx + ww // 2 - 150, wy - 26))
    text(img, (wx + ww // 2, wy - 26 + 22), "길드원", 22, anchor="mm", black=True)
    img.alpha_composite(sprite("button_close").resize((44, 44), Image.LANCZOS), (wx + ww - 34, wy - 12))

    tx = wx + 30
    for i, (lb, act) in enumerate([("이솔의 파티 · 자율 사냥", True), ("대기 중", False)]):
        t = nine("tab_active" if act else "tab_inactive", 190 if act else 110, 34, (28, 20, 28, 0))
        img.alpha_composite(t, (tx, wy + 46))
        text(img, (tx + t.width // 2, wy + 46 + 18), lb, 13, anchor="mm", stroke=2,
             fill=(255, 255, 255, 255) if act else (210, 200, 230, 255))
        tx += t.width + 6
    listw = nine("panel_well", ww - 52, 300, (28, 28, 28, 28))
    img.alpha_composite(listw, (wx + 26, wy + 80))

    members = [("이솔", "마법사 Lv.2 · INFP", "가치관 동료", 121, 121, 32, "귀환 중", "guild"),
               ("제나", "전사 Lv.2 · ESTP", "가치관 모험", 161, 202, 42, "귀환 중", "hp"),
               ("노아", "궁수 Lv.1 · ISFP", "가치관 안전", 151, 151, 29, "자율 사냥", "exp")]
    ry = wy + 92
    for name, cls, val, hp, hpmax, fat, state, ic in members:
        card = nine("panel_card", ww - 76, 88, (36, 36, 36, 36))
        img.alpha_composite(card, (wx + 38, ry))
        slot = nine("slot", 64, 64, (30, 30, 30, 30))
        img.alpha_composite(slot, (wx + 50, ry + 12))
        img.alpha_composite(icon(ic, 44), (wx + 60, ry + 22))
        text(img, (wx + 126, ry + 14), name, 18, black=True)
        text(img, (wx + 126 + 46, ry + 18), cls, 12, fill=(215, 205, 235, 255), stroke=2)
        text(img, (wx + 126, ry + 40), val + "  ·  " + state, 12, fill=(255, 214, 110, 255), stroke=2)
        bar(img, wx + 126, ry + 60, 170, 18, "hp", hp / hpmax, f"HP {hp}/{hpmax}")
        bar(img, wx + 304, ry + 60, 110, 18, "stamina", 1 - fat / 100, f"피로 {fat}")
        button(img, wx + ww - 150, ry + 10, 96, 34, "blue", "상세", 14)
        button(img, wx + ww - 150, ry + 46, 96, 34, "purple", "관리", 14)
        ry += 96

    button(img, wx + 30, wy + wh - 70, 220, 44, "green", "모집 공고 (80G)", 16)
    button(img, wx + ww - 170, wy + wh - 70, 140, 44, "gray", "닫기", 16)

    # --- tooltip example
    tip = nine("tooltip", 230, 54, (24, 24, 24, 24))
    shadow(img, tip, (wx + ww + 12, wy + 150), 6, (0, 4), 90)
    text(img, (wx + ww + 26, wy + 160), "피로가 쌓이면 실수가 늘어요.", 12, stroke=0)
    text(img, (wx + ww + 26, wy + 180), "휴식으로 회복합니다.", 12, fill=(200, 190, 220, 255), stroke=0)

    img.save(os.path.join(OUT, "mockup_after.png"))
    print("saved", img.size)


if __name__ == "__main__":
    build(sys.argv[1])
