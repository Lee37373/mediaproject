#!/usr/bin/env python3
"""Adds the F-8 (quest proposals) wiring to five existing files. Idempotent; keeps each file's line endings.

usage: apply_f8_wiring.py ROOT      (ROOT contains Scripts/... as under Assets/GuildMaster)
"""
import sys
from pathlib import Path

root = Path(sys.argv[1])


def patch(rel, edits):
    p = root / rel
    raw = p.read_bytes().decode("utf-8")
    crlf = "\r\n" in raw
    text = raw.replace("\r\n", "\n")
    changed = False
    for marker, old, new in edits:
        if marker in text:
            print(f"  {rel}: '{marker}' already there")
            continue
        if text.count(old) != 1:
            raise SystemExit(f"{rel}: anchor found {text.count(old)} times (need 1): {old[:70]!r}")
        text = text.replace(old, new)
        changed = True
        print(f"  {rel}: added '{marker}'")
    if crlf:
        text = text.replace("\n", "\r\n")
    if changed:
        p.write_bytes(text.encode("utf-8"))


patch("Scripts/Gameplay/Notifications/NotificationCenter.cs", [
    ("Management, Proposals }",
     "Report, Management }",
     "Report, Management, Proposals }"),
    ("NotificationLink Proposals()",
     "        public static NotificationLink Management(string adventurerId) => new(NotificationTarget.Management, adventurerId, default);\n",
     "        public static NotificationLink Management(string adventurerId) => new(NotificationTarget.Management, adventurerId, default);\n"
     "        /// <summary>The quest proposal list (F-8).</summary>\n"
     "        public static NotificationLink Proposals() => new(NotificationTarget.Proposals, null, default);\n"),
])

patch("Scripts/UI/Views/NotificationActions.cs", [
    ("NotificationTarget.Proposals",
     "                case NotificationTarget.Report:\n",
     "                case NotificationTarget.Proposals:\n"
     "                    Show<QuestProposalView>();\n"
     "                    break;\n"
     "                case NotificationTarget.Report:\n"),
])

patch("Scripts/UI/UIRoot.cs", [
    ("AddWindow<QuestProposalView>",
     "            AddWindow<MemberCareView>(null, null, Key.None, new Vector2(640, 640));\n",
     "            AddWindow<MemberCareView>(null, null, Key.None, new Vector2(640, 640));\n"
     "            // Ready-made quests to choose from (F-8); opened from the quest board and the proposal notification.\n"
     "            AddWindow<QuestProposalView>(null, null, Key.None, new Vector2(920, 640));\n"),
])

patch("Scripts/Gameplay/Session/GameBootstrap.cs", [
    ("Proposals.QuestProposalService",
     "            Services.Register(new Welfare.GuildWelfare(clock, roster, treasury, board, notifications));\n",
     "            Services.Register(new Welfare.GuildWelfare(clock, roster, treasury, board, notifications));\n"
     "            // Quest proposals (F-8): the LLM (or the rules) offers a few quests to choose from instead of the posting form.\n"
     "            Services.Register(new Proposals.QuestProposalService(board, intel, roster, treasury, clock, notifications));\n"),
])

patch("Scripts/UI/Views/QuestBoardView.cs", [
    ("OpenProposals",
     "            UIBuilder.Label(left, \"진행 중인 의뢰\", 17, TextAnchor.MiddleLeft, UITheme.Accent).Size(-1, 26);\n",
     "            var listHeader = UIBuilder.Row(left, 30, 8);\n"
     "            UIBuilder.Label(listHeader, \"진행 중인 의뢰\", 17, TextAnchor.MiddleLeft, UITheme.Accent).Size(-1, 26, 1);\n"
     "            UIBuilder.Button(listHeader, \"의뢰 제안 받기\", OpenProposals, 150, 28, new Color(0.25f, 0.45f, 0.3f), 14)\n"
     "                .Tooltip(() => \"길드가 아는 정보로 의뢰 후보를 몇 개 제안받고, 마음에 드는 것을 골라 등록합니다.\");\n"),
    ("void OpenProposals()",
     "        static RectTransform FieldRow(Transform parent, string label)\n",
     "        void OpenProposals()\n"
     "        {\n"
     "            if (!Services.TryGet<QuestProposalView>(out var view)) return;\n"
     "            if (!view.Visible) view.Open();\n"
     "            else view.BringToFront();\n"
     "        }\n"
     "\n"
     "        static RectTransform FieldRow(Transform parent, string label)\n"),
])
print("done")
