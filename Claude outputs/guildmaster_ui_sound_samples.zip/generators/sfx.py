"""Synthesised sample sounds for Guild Master (UI, combat, events) + a short town loop.
Everything is generated from oscillators and noise, so the files are ours to use freely."""
import os
import numpy as np
from scipy import signal
from scipy.io import wavfile

SR = 44100
OUT = os.path.join(os.path.dirname(__file__), "out", "sounds")
rng = np.random.default_rng(7)


def t_of(dur):
    return np.arange(int(dur * SR)) / SR


def env(n, attack=0.004, decay=0.15, curve=1.0):
    t = np.arange(n) / SR
    a = np.clip(t / max(attack, 1e-4), 0, 1)
    d = np.exp(-np.maximum(t - attack, 0) / max(decay, 1e-4) * curve)
    return a * d


def osc(freq, dur, kind="sine", phase0=0.0):
    """freq may be a scalar or an array (glide)."""
    n = int(dur * SR)
    f = np.broadcast_to(np.asarray(freq, dtype=float), (n,)) if np.ndim(freq) else np.full(n, float(freq))
    ph = phase0 + 2 * np.pi * np.cumsum(f) / SR
    if kind == "sine":
        return np.sin(ph)
    if kind == "tri":
        return 2 / np.pi * np.arcsin(np.sin(ph))
    if kind == "soft_square":
        return np.tanh(3 * np.sin(ph)) / np.tanh(3)
    if kind == "saw":
        return 2 * ((ph / (2 * np.pi)) % 1) - 1
    raise ValueError(kind)


def glide(f0, f1, dur, shape=1.0):
    t = np.linspace(0, 1, int(dur * SR)) ** shape
    return f0 * (f1 / f0) ** t


def noise(dur):
    return rng.standard_normal(int(dur * SR))


def band(x, lo, hi, order=2):
    b, a = signal.butter(order, [lo / (SR / 2), min(hi / (SR / 2), 0.99)], "band")
    return signal.lfilter(b, a, x)


def lowpass(x, hz, order=2):
    b, a = signal.butter(order, hz / (SR / 2), "low")
    return signal.lfilter(b, a, x)


def highpass(x, hz, order=2):
    b, a = signal.butter(order, hz / (SR / 2), "high")
    return signal.lfilter(b, a, x)


def sweep_band(x, f0, f1, q=3.0, steps=48):
    """Band-pass whose centre moves from f0 to f1 (block-wise)."""
    out = np.zeros_like(x)
    n = len(x)
    edges = np.linspace(0, n, steps + 1).astype(int)
    zi = None
    for i in range(steps):
        c = f0 * (f1 / f0) ** (i / max(steps - 1, 1))
        lo, hi = c / (1 + 1 / q), min(c * (1 + 1 / q), SR / 2 * 0.98)
        b, a = signal.butter(2, [lo / (SR / 2), hi / (SR / 2)], "band")
        if zi is None or len(zi) != max(len(a), len(b)) - 1:
            zi = signal.lfilter_zi(b, a) * 0
        seg, zi = signal.lfilter(b, a, x[edges[i]:edges[i + 1]], zi=zi)
        out[edges[i]:edges[i + 1]] = seg
    return out


def bell(freq, dur, decay=0.35, bright=1.0):
    """FM bell: inharmonic, bright attack, long decay."""
    t = t_of(dur)
    mod = np.sin(2 * np.pi * freq * 3.5 * t) * (2.2 * bright) * np.exp(-t / (decay * 0.4))
    car = np.sin(2 * np.pi * freq * t + mod)
    car += 0.3 * np.sin(2 * np.pi * freq * 2.01 * t) * np.exp(-t / (decay * 0.5))
    return car * env(len(t), 0.002, decay)


def pluck(freq, dur, damp=0.996, bright=0.5):
    """Karplus-Strong string."""
    n = int(dur * SR)
    p = max(int(SR / freq), 2)
    buf = rng.uniform(-1, 1, p)
    buf = lowpass(buf, 2000 + 8000 * bright, 1) if p > 16 else buf
    out = np.zeros(n)
    for i in range(n):
        out[i] = buf[i % p]
        buf[i % p] = damp * 0.5 * (buf[i % p] + buf[(i + 1) % p])
    return out * env(n, 0.001, dur * 0.6, 1.0)


def reverb(x, size=0.35, mix=0.18, damp_hz=5000):
    n = int(size * SR)
    ir = rng.standard_normal(n) * np.exp(-np.arange(n) / SR / (size / 5))
    ir = lowpass(ir, damp_hz, 1)
    ir /= np.sqrt(np.sum(ir ** 2))
    dry = np.concatenate([x, np.zeros(n)])
    wet = signal.fftconvolve(x, ir)[: len(dry)]
    wet = np.pad(wet, (0, len(dry) - len(wet)))
    return dry * (1 - mix) + wet * mix * 0.6


def place(total, *parts):
    """parts: (start_seconds, samples, gain)"""
    n = max([int(total * SR)] + [int(st * SR) + len(x) for st, x, _ in parts])
    out = np.zeros(n)
    for start, x, g in parts:
        x = np.array(x, dtype=float)
        k = min(int(0.006 * SR), len(x) // 3)  # no clicks where a part starts or stops
        if k > 0:
            x[-k:] *= np.linspace(1, 0, k) ** 2
            x[: k // 6 + 1] *= np.linspace(0, 1, k // 6 + 1)
        s = int(start * SR)
        e = min(n, s + len(x))
        out[s:e] += g * x[: e - s]
    return out


def finish(x, peak_db=-3.0, fade=0.01, trim=True):
    x = np.asarray(x, dtype=float)
    if trim:
        x = x - np.mean(x)
    if trim:
        thr = np.max(np.abs(x)) * 10 ** (-60 / 20)
        idx = np.nonzero(np.abs(x) > thr)[0]
        if len(idx):
            x = x[: idx[-1] + int(0.02 * SR)]
    f = min(int(fade * SR), len(x) // 4)
    if f > 0:  # a loop (fade 0) keeps its ends so it joins without a dip
        x[-f:] *= np.linspace(1, 0, f)
        x[: min(32, len(x))] *= np.linspace(0, 1, min(32, len(x)))
    x = x / (np.max(np.abs(x)) + 1e-9) * 10 ** (peak_db / 20)
    return x


def save(name, x, peak_db=-3.0, trim=True):
    os.makedirs(OUT, exist_ok=True)
    y = finish(x, peak_db, fade=0.01 if trim else 0.0, trim=trim)
    wavfile.write(os.path.join(OUT, name + ".wav"), SR, (y * 32767).astype(np.int16))
    return len(y) / SR


def note(name):
    names = {"C": 0, "C#": 1, "D": 2, "D#": 3, "E": 4, "F": 5, "F#": 6, "G": 7, "G#": 8, "A": 9, "A#": 10, "B": 11}
    pitch, octv = name[:-1], int(name[-1])
    return 440.0 * 2 ** ((names[pitch] + 12 * (octv + 1) - 69) / 12)


# ------------------------------------------------------------------ UI
def ui_click():
    d = 0.07
    body = osc(glide(1400, 700, d), d) * env(int(d * SR), 0.001, 0.018)
    tick = highpass(noise(0.004), 3000) * 0.4
    return place(d, (0, body, 1.0), (0, tick, 0.5))


def ui_open():
    d = 0.26
    sw = sweep_band(noise(d), 350, 3200, q=2.5) * env(int(d * SR), 0.09, 0.08)
    pop = osc(glide(600, 1100, 0.06), 0.06) * env(int(0.06 * SR), 0.002, 0.03)
    return reverb(place(d + 0.05, (0, sw, 1.0), (0.17, pop, 0.5)), 0.25, 0.15)


def ui_close():
    d = 0.22
    sw = sweep_band(noise(d), 2800, 300, q=2.5) * env(int(d * SR), 0.02, 0.07)
    pop = osc(glide(900, 450, 0.06), 0.06) * env(int(0.06 * SR), 0.002, 0.03)
    return reverb(place(d + 0.05, (0, sw, 1.0), (0.12, pop, 0.5)), 0.2, 0.12)


def ui_error():
    a = lowpass(osc(196, 0.11, "soft_square"), 1800) * env(int(0.11 * SR), 0.003, 0.08)
    b = lowpass(osc(165, 0.16, "soft_square"), 1600) * env(int(0.16 * SR), 0.003, 0.1)
    return place(0.32, (0, a, 1), (0.12, b, 1))


def notify():
    a = bell(note("E6"), 0.6, 0.25)
    b = bell(note("A6"), 0.9, 0.35)
    return reverb(place(1.0, (0, a, 0.7), (0.09, b, 0.8)), 0.4, 0.2)


# ------------------------------------------------------------------ economy
def coin_gain():
    a = bell(note("B6"), 0.25, 0.08, 1.4)
    b = bell(note("E7"), 0.7, 0.3, 1.4)
    return reverb(place(0.8, (0, a, 0.7), (0.07, b, 0.9)), 0.3, 0.15)


def coin_spend():
    parts = []
    t = 0.0
    for i in range(7):
        f = rng.uniform(3200, 5600)
        parts.append((t, bell(f, 0.18, rng.uniform(0.03, 0.07), 1.6), rng.uniform(0.35, 0.8)))
        t += rng.uniform(0.025, 0.06)
    thud = lowpass(noise(0.05), 600) * env(int(0.05 * SR), 0.001, 0.02)
    parts.append((0.0, thud, 0.6))
    return reverb(place(0.6, *parts), 0.25, 0.12)


# ------------------------------------------------------------------ combat
def hit_sword():
    d = 0.18
    slash = sweep_band(noise(d), 5500, 1500, q=2.0) * env(int(d * SR), 0.002, 0.04)
    thud = osc(glide(160, 55, 0.12), 0.12) * env(int(0.12 * SR), 0.001, 0.05)
    clank = bell(2350, 0.15, 0.05, 2.0)
    return place(0.25, (0, slash, 0.8), (0.005, thud, 1.0), (0.004, clank, 0.18))


def hit_blunt():
    thud = osc(glide(110, 40, 0.2), 0.2) * env(int(0.2 * SR), 0.001, 0.07)
    crunch = lowpass(noise(0.12), 1500) * env(int(0.12 * SR), 0.001, 0.03)
    return place(0.25, (0, thud, 1.0), (0, crunch, 0.7))


def arrow_shot():
    d = 0.14
    whip = sweep_band(noise(d), 4500, 900, q=3.0) * env(int(d * SR), 0.003, 0.04)
    twang = pluck(165, 0.25, 0.99, 0.8)
    return place(0.3, (0, twang, 0.6), (0.01, whip, 0.9))


def magic_cast():
    d = 0.7
    t = t_of(d)
    f = glide(500, 1250, d, 0.7) * (1 + 0.01 * np.sin(2 * np.pi * 7 * t))
    tone = (osc(f, d, "tri") + 0.4 * osc(f * 1.5, d, "sine")) * env(len(t), 0.15, 0.35)
    parts = [(0, tone, 0.6)]
    for i in range(10):
        parts.append((rng.uniform(0.1, 0.6), bell(rng.uniform(2500, 5200), 0.25, 0.06, 0.6), rng.uniform(0.1, 0.25)))
    return reverb(place(d + 0.1, *parts), 0.5, 0.25)


def hit_magic():
    d = 0.3
    zap = osc(glide(2200, 260, d, 0.5), d, "saw")
    zap = lowpass(zap, 5000) * env(int(d * SR), 0.002, 0.08)
    fizz = band(noise(d), 2000, 8000) * env(int(d * SR), 0.002, 0.06)
    return reverb(place(0.35, (0, zap, 0.6), (0, fizz, 0.35)), 0.3, 0.2)


def monster_die():
    d = 0.35
    pop = osc(glide(520, 140, 0.18, 0.6), 0.18) * env(int(0.18 * SR), 0.002, 0.06)
    puff = lowpass(noise(d), 1200) * env(int(d * SR), 0.02, 0.1)
    return reverb(place(0.45, (0, pop, 1.0), (0.03, puff, 0.6)), 0.3, 0.15)


def person_down():
    a = lowpass(osc(note("D4"), 0.25, "tri"), 2500) * env(int(0.25 * SR), 0.01, 0.15)
    b = lowpass(osc(glide(note("A3"), note("F3"), 0.6), 0.6, "tri"), 2000) * env(int(0.6 * SR), 0.01, 0.35)
    thud = osc(glide(90, 45, 0.15), 0.15) * env(int(0.15 * SR), 0.001, 0.06)
    return reverb(place(0.95, (0, thud, 0.8), (0.05, a, 0.6), (0.28, b, 0.6)), 0.5, 0.2)


# ------------------------------------------------------------------ progress
def level_up():
    seq = ["C5", "E5", "G5", "C6"]
    parts = []
    for i, n in enumerate(seq):
        dur = 0.12 if i < 3 else 0.7
        x = (osc(note(n), dur, "soft_square") * 0.5 + osc(note(n) * 2, dur, "tri") * 0.3)
        x = lowpass(x, 5000) * env(int(dur * SR), 0.004, 0.08 if i < 3 else 0.35)
        parts.append((i * 0.085, x, 0.7))
    for i in range(8):
        parts.append((0.3 + rng.uniform(0, 0.45), bell(rng.uniform(2600, 4800), 0.3, 0.08, 0.5), 0.2))
    return reverb(place(1.2, *parts), 0.6, 0.25)


def heal():
    d = 0.9
    chord = sum(osc(note(n), d, "tri") for n in ["F5", "A5", "C6"]) / 3
    chord = chord * env(int(d * SR), 0.12, 0.4)
    parts = [(0, chord, 0.5)]
    for i, n in enumerate(["C6", "F6", "A6", "C7"]):
        parts.append((0.08 + i * 0.09, bell(note(n), 0.5, 0.15, 0.4), 0.3))
    return reverb(place(1.1, *parts), 0.6, 0.3)


def quest_complete():
    seq = [("G4", 0.1), ("C5", 0.1), ("E5", 0.1), ("G5", 0.18), ("E5", 0.1), ("G5", 0.7)]
    parts, t = [], 0.0
    for n, dur in seq:
        x = place(dur + 0.4, (0, pluck(note(n), dur + 0.4, 0.997, 0.7), 0.8),
                  (0, lowpass(osc(note(n), dur + 0.2, "tri"), 4000) * env(int((dur + 0.2) * SR), 0.005, dur), 0.4))
        parts.append((t, x, 0.7))
        t += dur
    for n in ["C4", "E4", "G4"]:
        parts.append((t - 0.7, pluck(note(n), 1.0, 0.998, 0.4), 0.35))
    parts.append((t - 0.7, coin_gain(), 0.35))
    return reverb(place(t + 0.9, *parts), 0.6, 0.22)


def recruit_success():
    seq = [("C5", 0.11), ("E5", 0.11), ("G5", 0.11), ("C6", 0.5)]
    parts, t = [], 0.0
    for n, dur in seq:
        x = lowpass(osc(note(n), dur + 0.15, "tri") + 0.3 * osc(note(n) * 2, dur + 0.15), 6000)
        parts.append((t, x * env(len(x), 0.004, dur * 0.9), 0.6))
        t += dur * 0.85
    parts.append((t - 0.4, bell(note("C7"), 0.8, 0.3, 0.6), 0.25))
    return reverb(place(t + 0.6, *parts), 0.5, 0.22)


def recruit_fail():
    seq = [("E4", 0.22), ("D#4", 0.22), ("D4", 0.22), ("C#4", 0.6)]
    parts, t = [], 0.0
    for i, (n, dur) in enumerate(seq):
        tt = t_of(dur)
        vib = 1 + (0.012 * np.sin(2 * np.pi * 6 * tt) if i == 3 else 0)
        x = lowpass(osc(note(n) * vib, dur, "saw"), 1400) * env(len(tt), 0.01, dur * 0.7)
        parts.append((t, x, 0.55))
        t += dur * 0.9
    return reverb(place(t + 0.4, *parts), 0.4, 0.18)


def event_card():
    parts = []
    for i in range(3):
        flip = sweep_band(noise(0.06), 1500, 4500, q=1.5) * env(int(0.06 * SR), 0.002, 0.015)
        parts.append((i * 0.045, flip, 0.5 - i * 0.12))
    parts.append((0.16, bell(note("G5"), 0.6, 0.2, 0.7), 0.5))
    parts.append((0.24, bell(note("D6"), 0.9, 0.3, 0.7), 0.5))
    return reverb(place(1.1, *parts), 0.5, 0.2)


def day_start():
    parts = []
    for i, n in enumerate(["G5", "B5", "D6", "G6"]):
        parts.append((i * 0.16, bell(note(n), 1.3, 0.45, 0.45), 0.5))
    return reverb(place(2.0, *parts), 0.9, 0.3)


def night_fall():
    parts = []
    for i, n in enumerate(["E5", "C5", "A4"]):
        parts.append((i * 0.22, bell(note(n), 1.5, 0.5, 0.35), 0.5))
    pad = sum(osc(note(n), 1.6, "tri") for n in ["A3", "C4", "E4"]) / 3 * env(int(1.6 * SR), 0.4, 0.6)
    parts.append((0.0, pad, 0.25))
    return reverb(place(2.2, *parts), 1.0, 0.35)


# Peak level per sound (dBFS): UI quieter than combat, jingles in between.
LEVEL = {"ui_click": -10, "ui_open": -8, "ui_close": -9, "ui_error": -11, "notify": -7, "coin_gain": -6,
         "coin_spend": -7, "monster_die": -4, "person_down": -5, "event_card": -6, "day_start": -7, "night_fall": -7}

SOUNDS = [
    ("ui_click", ui_click, "버튼 클릭"),
    ("ui_open", ui_open, "창 열기"),
    ("ui_close", ui_close, "창 닫기"),
    ("ui_error", ui_error, "불가/오류 (골드 부족 등)"),
    ("notify", notify, "알림"),
    ("coin_gain", coin_gain, "골드 획득 (의뢰 보상, 상납)"),
    ("coin_spend", coin_spend, "골드 지출 (구매, 모집 공고)"),
    ("hit_sword", hit_sword, "검/도끼 타격"),
    ("hit_blunt", hit_blunt, "둔기 타격, 몬스터 공격"),
    ("arrow_shot", arrow_shot, "활 발사"),
    ("magic_cast", magic_cast, "스킬/마법 시전"),
    ("hit_magic", hit_magic, "마법 명중"),
    ("monster_die", monster_die, "몬스터 처치"),
    ("person_down", person_down, "길드원 쓰러짐"),
    ("level_up", level_up, "레벨 업"),
    ("heal", heal, "회복"),
    ("quest_complete", quest_complete, "의뢰 완료"),
    ("recruit_success", recruit_success, "영입 성공"),
    ("recruit_fail", recruit_fail, "영입 실패"),
    ("event_card", event_card, "사건 카드 등장"),
    ("day_start", day_start, "아침 (새 날)"),
    ("night_fall", night_fall, "밤이 됨"),
]


# ------------------------------------------------------------------ music: town loop
def town_loop():
    bpm = 104
    beat = 60 / bpm
    bars = 8
    total = bars * 4 * beat
    chords = [["C3", "E3", "G3"], ["A2", "C3", "E3"], ["F2", "A2", "C3"], ["G2", "B2", "D3"],
              ["C3", "E3", "G3"], ["A2", "C3", "E3"], ["F2", "A2", "C3"], ["G2", "B2", "D3"]]
    # melody: (beat position, note, length in beats)
    mel = [
        (0, "E5", 1), (1, "G5", 1), (2, "A5", 0.5), (2.5, "G5", 0.5), (3, "E5", 1),
        (4, "C5", 1), (5, "D5", 0.5), (5.5, "E5", 0.5), (6, "D5", 1.5),
        (8, "C5", 1), (9, "A4", 1), (10, "C5", 0.5), (10.5, "D5", 0.5), (11, "F5", 1),
        (12, "E5", 1), (13, "D5", 1), (14, "B4", 1), (15, "D5", 1),
        (16, "E5", 1), (17, "G5", 1), (18, "A5", 0.5), (18.5, "C6", 0.5), (19, "A5", 1),
        (20, "G5", 1), (21, "E5", 0.5), (21.5, "G5", 0.5), (22, "A5", 1.5),
        (24, "F5", 1), (25, "E5", 1), (26, "D5", 0.5), (26.5, "C5", 0.5), (27, "A4", 1),
        (28, "B4", 1), (29, "D5", 1), (30, "C5", 2),
    ]
    n = int(total * SR)
    tail = int(2.0 * SR)
    mix = np.zeros(n + tail)

    def add(start_s, x, g):
        x = place(len(x) / SR, (0, x, 1.0))
        s = int(start_s * SR)
        e = min(len(mix), s + len(x))
        mix[s:e] += g * x[: e - s]

    for pos, nm, ln in mel:
        x = pluck(note(nm), ln * beat + 0.5, 0.9965, 0.75)
        add(pos * beat, x, 0.55)
        add(pos * beat, lowpass(osc(note(nm) * 2, ln * beat, "sine"), 6000) * env(int(ln * beat * SR), 0.01, ln * beat * 0.5), 0.05)
    for b, ch in enumerate(chords):
        root = note(ch[0]) / 2
        for k in range(4):  # bass on 1 and 3, arpeggio on every half beat
            if k in (0, 2):
                add((b * 4 + k) * beat, pluck(root if k == 0 else root * 1.5, beat * 1.6, 0.997, 0.3), 0.55)
        for h in range(8):
            nm = ch[[0, 1, 2, 1][h % 4]]
            add((b * 4 + h * 0.5) * beat, pluck(note(nm) * 2, beat, 0.993, 0.45), 0.18)
        pad = sum(osc(note(c) * 2, 4 * beat, "tri") for c in ch) / 3
        pad = lowpass(pad, 1800) * env(int(4 * beat * SR), 0.5, 3.0)
        add(b * 4 * beat, pad, 0.07)
        for k in range(8):  # light shaker
            s = band(noise(0.05), 5000, 12000) * env(int(0.05 * SR), 0.003, 0.015)
            add((b * 4 + k * 0.5) * beat, s, 0.05 if k % 2 else 0.08)
    wet = reverb(mix, 1.2, 0.22)
    loop = wet[:n].copy()
    loop[: len(wet) - n] += wet[n:]  # wrap the tail so the loop is seamless
    return loop


if __name__ == "__main__":
    rows = []
    for key, fn, label in SOUNDS:
        secs = save(key, fn(), LEVEL.get(key, -4))
        rows.append((key, label, secs))
        print(f"{key:16s} {secs:5.2f}s  {label}")
    secs = save("bgm_town_loop", town_loop(), -4.0, trim=False)
    print(f"bgm_town_loop    {secs:5.2f}s")
