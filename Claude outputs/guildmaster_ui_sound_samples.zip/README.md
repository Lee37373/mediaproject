# Guild Master — UI·사운드 샘플 (2026-10-30)

게임에는 아직 넣지 않았습니다. 전부 직접 생성한 것이라 라이선스 제약이 없습니다(팀 git에 넣어도 됨).

## sounds/ (44.1kHz 16-bit mono WAV)
| 파일 | 쓰일 곳 |
|---|---|
| ui_click / ui_open / ui_close | 버튼, 창 열기·닫기 |
| ui_error | 골드 부족 등 불가 |
| notify | 알림 |
| coin_gain / coin_spend | 보상·상납 / 구매·모집 공고 |
| hit_sword / hit_blunt / arrow_shot / hit_magic | 타격·발사 (전사·몬스터 / 궁수 / 마법사) |
| magic_cast | 스킬 사용 |
| monster_die / person_down | 몬스터 처치 / 길드원 쓰러짐 |
| level_up / heal | 레벨 업 / 회복 |
| quest_complete / recruit_success / recruit_fail | 의뢰 완료 / 영입 성공·실패 |
| event_card | 사건 카드 등장 |
| day_start / night_fall | 아침 / 밤 |
| bgm_town_loop | 마을 BGM (18초 루프, 시험용 수준) |

Unity 임포트 권장: 짧은 효과음은 Load Type = Decompress On Load, BGM은 Streaming + Vorbis.

## ui/ (PNG, 2배 해상도)
- panel_window_purple / panel_window_parchment: 창 배경
- panel_card / panel_well: 목록 카드 / 움푹한 영역
- button_{green,blue,red,yellow,purple,gray}(+_pressed)
- title_ribbon_{red,purple}, button_close, tab_active / tab_inactive, tooltip
- slot / slot_selected, bar_back + bar_fill_{hp,stamina,exp,gold}
- icon_{gold,food,exp,material,hp,potion,quest,guild} (128px)
- ui_slices.json: 9-slice 테두리값 (Unity Sprite Editor Border L,B,R,T 순서) — Image Type = Sliced

## 다시 만들기
`python3 sfx.py`, `python3 ui.py`, `python3 mockup.py <스크린샷>` (numpy, scipy, Pillow). 색·크기·소리 길이는 스크립트 상단 값으로 조절.
