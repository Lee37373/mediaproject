"""Sample UI sprites for Guild Master: thick dark outlines, soft gradients and a bottom lip, to sit next to the
LAYERLAB cartoon characters. All drawn here (no third-party art), exported at 2x with 9-slice borders listed in
ui_slices.json."""
import json
import math
import os
from PIL import Image, ImageDraw, ImageFilter

SS = 4  # supersampling
OUT = os.path.join(os.path.dirname(__file__), "out", "ui")
INK = (42, 31, 51, 255)  # outline colour
SLICES = {}


def hexc(h, a=255):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4)) + (a,)


def mix(c1, c2, t):
    return tuple(int(round(c1[i] + (c2[i] - c1[i]) * t)) for i in range(4))


def shade(c, k):
    """k>0 lighter towards white, k<0 darker towards ink."""
    return mix(c, (255, 255, 255, c[3]), k) if k > 0 else mix(c, (30, 20, 40, c[3]), -k)


def rr_mask(size, box, r):
    m = Image.new("L", size, 0)
    ImageDraw.Draw(m).rounded_rectangle(box, r, fill=255)
    return m


def vgrad(size, top, bottom):
    w, h = size
    g = Image.new("RGBA", (1, h))
    for y in range(h):
        g.putpixel((0, y), mix(top, bottom, y / max(h - 1, 1)))
    return g.resize((w, h))


def paste_fill(img, box, r, fill):
    """fill: colour or (top, bottom) gradient."""
    x0, y0, x1, y1 = [int(v) for v in box]
    if isinstance(fill[0], tuple):
        layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
        layer.paste(vgrad((x1 - x0, y1 - y0), fill[0], fill[1]), (x0, y0))
    else:
        layer = Image.new("RGBA", img.size, fill)
    img.alpha_composite(Image.composite(layer, Image.new("RGBA", img.size, (0, 0, 0, 0)), rr_mask(img.size, box, r)))


def save(img, name, border=None):
    os.makedirs(OUT, exist_ok=True)
    final = img.resize((img.width // SS, img.height // SS), Image.LANCZOS)
    final.save(os.path.join(OUT, name + ".png"))
    if border is not None:
        L, T, R, B = border
        SLICES[name] = {"size": list(final.size), "unity_border_LBRT": [L, B, R, T]}
    return final


# ------------------------------------------------------------------ boxes
def box(w, h, base, radius=20, ow=5, lip=0, gloss=True, inner_line=True, pressed=False):
    """w,h in output pixels (2x art). Returns a supersampled image."""
    W, H, R, OW, LIP = w * SS, h * SS, radius * SS, ow * SS, lip * SS
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    top_pad = LIP if pressed else 0
    paste_fill(img, (0, top_pad, W, H), R, INK)
    if LIP and not pressed:
        paste_fill(img, (OW, OW, W - OW, H - OW), R - OW, shade(base, -0.35))
        face = (OW, OW, W - OW, H - OW - LIP)
    else:
        face = (OW, top_pad + OW, W - OW, H - OW)
    paste_fill(img, face, R - OW, (shade(base, 0.18), shade(base, -0.08)))
    fx0, fy0, fx1, fy1 = face
    if inner_line:  # thin light rim inside the outline
        rim = Image.new("RGBA", img.size, (0, 0, 0, 0))
        ImageDraw.Draw(rim).rounded_rectangle(face, R - OW, outline=shade(base, 0.45)[:3] + (150,), width=int(1.5 * SS))
        img.alpha_composite(rim)
    if gloss:  # soft highlight band on the upper part
        gh = (fy1 - fy0) * 0.42
        pad = 3 * SS
        hl = Image.new("RGBA", img.size, (0, 0, 0, 0))
        paste_fill(hl, (fx0 + pad, fy0 + pad, fx1 - pad, fy0 + pad + gh), max(R - OW - pad, 2 * SS),
                   ((255, 255, 255, 95), (255, 255, 255, 20)))
        img.alpha_composite(hl)
        dot = Image.new("RGBA", img.size, (0, 0, 0, 0))
        d = ImageDraw.Draw(dot)
        cx, cy, rr = fx0 + R * 0.55, fy0 + R * 0.45, 2.6 * SS
        d.ellipse((cx - rr, cy - rr, cx + rr, cy + rr), fill=(255, 255, 255, 200))
        d.ellipse((cx + rr * 2.2 - rr * 0.6, cy - rr * 0.6, cx + rr * 2.2 + rr * 0.6, cy + rr * 0.6), fill=(255, 255, 255, 160))
        img.alpha_composite(dot)
    return img


def well(w, h, base, radius=14, ow=3):
    """Inset area (lists, slots): darker, inner shadow at the top."""
    W, H, R, OW = w * SS, h * SS, radius * SS, ow * SS
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    paste_fill(img, (0, 0, W, H), R, shade(base, -0.45))
    paste_fill(img, (OW, OW, W - OW, H - OW), R - OW, (shade(base, -0.25), shade(base, -0.05)))
    sh = Image.new("RGBA", img.size, (0, 0, 0, 0))
    paste_fill(sh, (OW, OW, W - OW, OW + 7 * SS), R - OW, ((0, 0, 0, 90), (0, 0, 0, 0)))
    img.alpha_composite(sh)
    return img


def panel(w, h, base, rim, radius=28, ow=6):
    """Window: outline, coloured rim, inner face."""
    W, H, R, OW = w * SS, h * SS, radius * SS, ow * SS
    RIM = 10 * SS
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    paste_fill(img, (0, 0, W, H), R, INK)
    paste_fill(img, (OW, OW, W - OW, H - OW), R - OW, (shade(rim, 0.25), shade(rim, -0.2)))
    inner = (OW + RIM, OW + RIM, W - OW - RIM, H - OW - RIM)
    paste_fill(img, (inner[0] - 2 * SS, inner[1] - 2 * SS, inner[2] + 2 * SS, inner[3] + 2 * SS), R - OW - RIM + 2 * SS, INK[:3] + (200,))
    paste_fill(img, inner, R - OW - RIM, (shade(base, 0.06), shade(base, -0.06)))
    hl = Image.new("RGBA", img.size, (0, 0, 0, 0))
    paste_fill(hl, (OW + 4 * SS, OW + 3 * SS, W - OW - 4 * SS, OW + RIM - 2 * SS), 4 * SS, (255, 255, 255, 110))
    img.alpha_composite(hl)
    for cx, cy in [(OW + RIM / 2, OW + RIM / 2), (W - OW - RIM / 2, OW + RIM / 2), (OW + RIM / 2, H - OW - RIM / 2), (W - OW - RIM / 2, H - OW - RIM / 2)]:
        d = ImageDraw.Draw(img)
        r = 4.5 * SS
        d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=INK)
        r2 = 3 * SS
        d.ellipse((cx - r2, cy - r2, cx + r2, cy + r2), fill=hexc("#f3c64e"))
    return img


def ribbon(w, h, base):
    W, H = w * SS, h * SS
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    tail = 0.16 * W
    body_top, body_bot = 0.08 * H, 0.78 * H
    fold_top, fold_bot = 0.28 * H, 0.98 * H
    notch = tail * 0.45
    dark = shade(base, -0.4)
    for side in (0, 1):
        x0 = 0 if side == 0 else W - tail * 1.25
        x1 = tail * 1.25 if side == 0 else W
        pts = [(x0, fold_top), (x1, fold_top), (x1, fold_bot), (x0, fold_bot), ((x0 + notch) if side == 0 else (x1 - notch), (fold_top + fold_bot) / 2)]
        if side == 1:
            pts = [(x0, fold_top), (x1, fold_top), (x1 - notch, (fold_top + fold_bot) / 2), (x1, fold_bot), (x0, fold_bot)]
        d.polygon(pts, fill=INK)
        inset = 5 * SS
        cx = (x0 + x1) / 2
        small = [((px - cx) * 0.86 + cx, (py - (fold_top + fold_bot) / 2) * 0.8 + (fold_top + fold_bot) / 2) for px, py in pts]
        d.polygon(small, fill=dark)
    paste_fill(img, (tail, body_top, W - tail, body_bot), 10 * SS, INK)
    paste_fill(img, (tail + 5 * SS, body_top + 5 * SS, W - tail - 5 * SS, body_bot - 5 * SS), 6 * SS, (shade(base, 0.2), shade(base, -0.1)))
    hl = Image.new("RGBA", img.size, (0, 0, 0, 0))
    paste_fill(hl, (tail + 10 * SS, body_top + 9 * SS, W - tail - 10 * SS, body_top + (body_bot - body_top) * 0.38), 4 * SS, (255, 255, 255, 90))
    img.alpha_composite(hl)
    return img


def pill(w, h, base, ow=3):
    W, H, OW = w * SS, h * SS, ow * SS
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    paste_fill(img, (0, 0, W, H), H // 2, INK)
    paste_fill(img, (OW, OW, W - OW, H - OW), (H - 2 * OW) // 2, (shade(base, 0.2), shade(base, -0.15)))
    hl = Image.new("RGBA", img.size, (0, 0, 0, 0))
    paste_fill(hl, (OW + H * 0.2, OW + 2 * SS, W - OW - H * 0.2, OW + (H - 2 * OW) * 0.42), 3 * SS, (255, 255, 255, 110))
    img.alpha_composite(hl)
    return img


def circle_button(size, base, glyph="x"):
    S = size * SS
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse((0, 0, S, S - 2 * SS), fill=INK)
    d.ellipse((5 * SS, 5 * SS, S - 5 * SS, S - 5 * SS), fill=shade(base, -0.35))
    face = Image.new("RGBA", img.size, (0, 0, 0, 0))
    m = Image.new("L", img.size, 0)
    ImageDraw.Draw(m).ellipse((5 * SS, 5 * SS, S - 5 * SS, S - 10 * SS), fill=255)
    face.paste(vgrad((S, S), shade(base, 0.25), shade(base, -0.05)), (0, 0))
    img.alpha_composite(Image.composite(face, Image.new("RGBA", img.size, (0, 0, 0, 0)), m))
    c, r, w = S / 2, S * 0.17, int(S * 0.11)
    cy = S / 2 - 2.5 * SS
    if glyph == "x":
        for (a, b) in [((c - r, cy - r), (c + r, cy + r)), ((c - r, cy + r), (c + r, cy - r))]:
            d.line([a, b], fill=INK, width=w + 4 * SS)
        for (a, b) in [((c - r, cy - r), (c + r, cy + r)), ((c - r, cy + r), (c + r, cy - r))]:
            d.line([a, b], fill=(255, 255, 255, 255), width=w)
    hl = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(hl).ellipse((S * 0.22, S * 0.12, S * 0.5, S * 0.3), fill=(255, 255, 255, 120))
    img.alpha_composite(hl)
    return img


def tab(w, h, base, active):
    W, H, R, OW = w * SS, h * SS, 14 * SS, 4 * SS
    img = Image.new("RGBA", (W, H + R), (0, 0, 0, 0))
    col = base if active else shade(base, -0.35)
    paste_fill(img, (0, 0, W, H + R), R, INK)
    paste_fill(img, (OW, OW, W - OW, H + R), R - OW, (shade(col, 0.2), shade(col, -0.05)))
    if active:
        hl = Image.new("RGBA", img.size, (0, 0, 0, 0))
        paste_fill(hl, (OW + 4 * SS, OW + 3 * SS, W - OW - 4 * SS, OW + H * 0.35), 5 * SS, (255, 255, 255, 100))
        img.alpha_composite(hl)
    return img.crop((0, 0, W, H))


# ------------------------------------------------------------------ icons (128 px)
def icon_canvas():
    S = 128 * SS
    return Image.new("RGBA", (S, S), (0, 0, 0, 0)), S


def outline_shape(img, draw_fn, ow=7):
    """draw_fn(draw, grow) draws the silhouette; grow>0 is the outline pass."""
    S = img.width
    sil = Image.new("RGBA", img.size, (0, 0, 0, 0))
    draw_fn(ImageDraw.Draw(sil), 0)
    a = sil.split()[3].filter(ImageFilter.MaxFilter(ow * SS * 2 + 1 if ow * SS * 2 + 1 < 120 else 119))
    ink = Image.new("RGBA", img.size, INK)
    img.alpha_composite(Image.composite(ink, Image.new("RGBA", img.size, (0, 0, 0, 0)), a))
    img.alpha_composite(sil)


def icon_coin():
    img, S = icon_canvas()
    gold, dk = hexc("#f6c343"), hexc("#d68a1c")

    def f(d, g):
        d.ellipse((S * 0.14, S * 0.16, S * 0.86, S * 0.9), fill=dk)
        d.ellipse((S * 0.14, S * 0.1, S * 0.86, S * 0.82), fill=gold)
        d.ellipse((S * 0.25, S * 0.2, S * 0.75, S * 0.72), fill=shade(gold, -0.12))
        d.ellipse((S * 0.27, S * 0.21, S * 0.75, S * 0.7), fill=shade(gold, 0.08))
        d.rounded_rectangle((S * 0.45, S * 0.3, S * 0.55, S * 0.62), S * 0.04, fill=dk)
        d.ellipse((S * 0.29, S * 0.2, S * 0.4, S * 0.28), fill=(255, 255, 255, 190))
    outline_shape(img, f, 5)
    return img


def icon_star():
    img, S = icon_canvas()
    col = hexc("#ffd84a")

    def pts(cx, cy, r1, r2):
        p = []
        for i in range(10):
            a = -math.pi / 2 + i * math.pi / 5
            r = r1 if i % 2 == 0 else r2
            p.append((cx + r * math.cos(a), cy + r * math.sin(a)))
        return p

    def f(d, g):
        d.polygon(pts(S / 2, S * 0.54, S * 0.42, S * 0.19), fill=shade(col, -0.25))
        d.polygon(pts(S / 2, S * 0.5, S * 0.42, S * 0.19), fill=col)
        d.polygon(pts(S / 2, S * 0.5, S * 0.22, S * 0.1), fill=shade(col, 0.35))
        d.ellipse((S * 0.38, S * 0.24, S * 0.46, S * 0.32), fill=(255, 255, 255, 220))
    outline_shape(img, f, 5)
    return img


def icon_heart():
    img, S = icon_canvas()
    red = hexc("#ef4f5f")

    def heart(d, sc, col, dy=0):
        cx, cy = S / 2, S * 0.5 + dy
        r = S * 0.2 * sc
        d.ellipse((cx - 2 * r, cy - 1.6 * r, cx, cy + 0.4 * r), fill=col)
        d.ellipse((cx, cy - 1.6 * r, cx + 2 * r, cy + 0.4 * r), fill=col)
        d.polygon([(cx - 1.93 * r, cy - 0.35 * r), (cx + 1.93 * r, cy - 0.35 * r), (cx, cy + 1.95 * r)], fill=col)

    def f(d, g):
        heart(d, 1.0, shade(red, -0.3), S * 0.04)
        heart(d, 1.0, red)
        d.ellipse((S * 0.26, S * 0.3, S * 0.4, S * 0.42), fill=(255, 255, 255, 200))
    outline_shape(img, f, 5)
    return img


def icon_bread():
    img, S = icon_canvas()
    crust, light = hexc("#d98b3a"), hexc("#f2c27a")

    def f(d, g):
        d.rounded_rectangle((S * 0.12, S * 0.36, S * 0.88, S * 0.8), S * 0.2, fill=shade(crust, -0.2))
        d.ellipse((S * 0.12, S * 0.22, S * 0.88, S * 0.72), fill=crust)
        d.ellipse((S * 0.2, S * 0.27, S * 0.8, S * 0.6), fill=shade(crust, 0.15))
        for i in range(3):
            x = S * (0.32 + i * 0.16)
            d.line([(x - S * 0.05, S * 0.36), (x + S * 0.05, S * 0.5)], fill=light, width=int(S * 0.045))
        d.ellipse((S * 0.24, S * 0.3, S * 0.34, S * 0.37), fill=(255, 255, 255, 170))
    outline_shape(img, f, 5)
    return img


def icon_logs():
    img, S = icon_canvas()
    bark, wood, ring = hexc("#8a5a34"), hexc("#e3b071"), hexc("#b97a43")

    def log(d, x, y, r):  # a cut log seen end-on
        d.ellipse((x - r, y - r, x + r, y + r), fill=bark)
        d.ellipse((x - r * 0.78, y - r * 0.78, x + r * 0.78, y + r * 0.78), fill=wood)
        d.ellipse((x - r * 0.48, y - r * 0.48, x + r * 0.48, y + r * 0.48), outline=ring, width=int(S * 0.018))
        d.ellipse((x - r * 0.14, y - r * 0.14, x + r * 0.14, y + r * 0.14), fill=ring)

    def f(d, g):
        r = S * 0.19
        log(d, S * 0.31, S * 0.68, r)
        log(d, S * 0.69, S * 0.68, r)
        log(d, S * 0.5, S * 0.36, r)
    outline_shape(img, f, 5)
    return img


def icon_potion():
    img, S = icon_canvas()
    glass, liquid = hexc("#c9ecff", 255), hexc("#e8426a")

    def f(d, g):
        d.rounded_rectangle((S * 0.4, S * 0.08, S * 0.6, S * 0.2), S * 0.03, fill=hexc("#9b6a3d"))
        d.rectangle((S * 0.42, S * 0.18, S * 0.58, S * 0.36), fill=glass)
        d.ellipse((S * 0.18, S * 0.3, S * 0.82, S * 0.92), fill=glass)
        d.chord((S * 0.22, S * 0.34, S * 0.78, S * 0.88), 10, 170, fill=liquid)
        d.ellipse((S * 0.3, S * 0.4, S * 0.4, S * 0.52), fill=(255, 255, 255, 220))
    outline_shape(img, f, 5)
    return img


def icon_scroll():
    img, S = icon_canvas()
    paper, edge = hexc("#f5e2b8"), hexc("#d9b77a")

    def f(d, g):
        d.rectangle((S * 0.22, S * 0.2, S * 0.78, S * 0.8), fill=paper)
        for y in (0.2, 0.8):
            d.ellipse((S * 0.14, S * (y - 0.08), S * 0.3, S * (y + 0.08)), fill=edge)
            d.rounded_rectangle((S * 0.18, S * (y - 0.08), S * 0.86, S * (y + 0.08)), S * 0.08, fill=edge)
        for i in range(3):
            d.line([(S * 0.32, S * (0.38 + i * 0.12)), (S * 0.68, S * (0.38 + i * 0.12))], fill=hexc("#a8865a"), width=int(S * 0.035))
        d.ellipse((S * 0.6, S * 0.58, S * 0.76, S * 0.74), fill=hexc("#d8424e"))
    outline_shape(img, f, 5)
    return img


def icon_shield():
    img, S = icon_canvas()
    steel, blue = hexc("#c8d3e0"), hexc("#4a7fd6")

    def f(d, g):
        top, bot = S * 0.12, S * 0.9
        d.polygon([(S * 0.16, top), (S * 0.84, top), (S * 0.84, S * 0.5), (S * 0.5, bot), (S * 0.16, S * 0.5)], fill=steel)
        d.polygon([(S * 0.24, top + S * 0.07), (S * 0.76, top + S * 0.07), (S * 0.76, S * 0.48), (S * 0.5, bot - S * 0.1), (S * 0.24, S * 0.48)], fill=blue)
        d.polygon([(S * 0.5, top + S * 0.07), (S * 0.76, top + S * 0.07), (S * 0.76, S * 0.48), (S * 0.5, bot - S * 0.1)], fill=shade(blue, -0.2))
        d.rectangle((S * 0.46, S * 0.22, S * 0.54, S * 0.66), fill=hexc("#f3c64e"))
        d.rectangle((S * 0.34, S * 0.36, S * 0.66, S * 0.44), fill=hexc("#f3c64e"))
    outline_shape(img, f, 5)
    return img


# ------------------------------------------------------------------ build all
COLORS = {"green": "#5cc36a", "blue": "#4f8fe6", "red": "#e5525b", "yellow": "#f3b93f", "purple": "#8a63d2", "gray": "#9a98a6"}


def build():
    save(panel(256, 256, hexc("#3b2f52"), hexc("#7a5bb5")), "panel_window_purple", [56, 56, 56, 56])
    save(panel(256, 256, hexc("#f4e6c8"), hexc("#b07a45")), "panel_window_parchment", [56, 56, 56, 56])
    save(box(160, 160, hexc("#4a3d63"), 22, 4, 0, gloss=False), "panel_card", [36, 36, 36, 36])
    save(well(160, 160, hexc("#3b2f52")), "panel_well", [28, 28, 28, 28])
    for name, hx in COLORS.items():
        save(box(200, 88, hexc(hx), 22, 5, 9), f"button_{name}", [36, 30, 36, 40])
        save(box(200, 88, hexc(hx), 22, 5, 9, pressed=True), f"button_{name}_pressed", [36, 40, 36, 30])
    save(ribbon(520, 120, hexc("#e5525b")), "title_ribbon_red", [120, 0, 120, 0])
    save(ribbon(520, 120, hexc("#8a63d2")), "title_ribbon_purple", [120, 0, 120, 0])
    save(well(104, 104, hexc("#4a3d63"), 18, 4), "slot", [30, 30, 30, 30])
    sel = well(104, 104, hexc("#4a3d63"), 18, 4)
    ImageDraw.Draw(sel).rounded_rectangle((2 * SS, 2 * SS, sel.width - 2 * SS, sel.height - 2 * SS), 17 * SS, outline=hexc("#ffd84a"), width=5 * SS)
    save(sel, "slot_selected", [30, 30, 30, 30])
    save(well(240, 36, hexc("#2c2340"), 18, 3), "bar_back", [18, 0, 18, 0])
    for name, hx in [("hp", "#ef4f5f"), ("stamina", "#5cc36a"), ("exp", "#4f8fe6"), ("gold", "#f3b93f")]:
        save(pill(240, 30, hexc(hx)), f"bar_fill_{name}", [15, 0, 15, 0])
    save(circle_button(84, hexc("#e5525b")), "button_close")
    save(tab(180, 64, hexc("#8a63d2"), True), "tab_active", [28, 20, 28, 0])
    save(tab(180, 64, hexc("#8a63d2"), False), "tab_inactive", [28, 20, 28, 0])
    save(box(240, 96, hexc("#241c33"), 16, 3, 0, gloss=False, inner_line=False), "tooltip", [24, 24, 24, 24])
    for nm, fn in [("gold", icon_coin), ("exp", icon_star), ("hp", icon_heart), ("food", icon_bread),
                   ("material", icon_logs), ("potion", icon_potion), ("quest", icon_scroll), ("guild", icon_shield)]:
        save(fn(), "icon_" + nm)
    with open(os.path.join(OUT, "ui_slices.json"), "w", encoding="utf-8") as f:
        json.dump({"note": "Sizes are 2x art: import with Pixels Per Unit 100 and Canvas Scaler reference 2x, or halve in "
                           "Image size. unity_border_LBRT = Sprite Editor Border (L, B, R, T) in pixels; use Image Type = Sliced.",
                   "sprites": SLICES},
                  f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    build()
    print(len(os.listdir(OUT)), "files")
